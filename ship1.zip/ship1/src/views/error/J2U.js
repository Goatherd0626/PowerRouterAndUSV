
var myUnity;
//获取横截面贴图
function getTexture_H(){
     myUnity.SendMessage("CallJs","GetColor_H")
}

//获取纵截面贴图
function getTexture_S(){
    myUnity.SendMessage("CallJs","GetColor_S")
}

//接收横截面贴图
function setTexture_H(texture){
    // GLctx.bindTexture(GLctx.TEXTURE_2D, GL.textures[texture]); //此处为OpenGL使用方式
    console.log("------------------------",texture);

}

//接收纵截面贴图
function setTexture_S(texture){
    // GLctx.bindTexture(GLctx.TEXTURE_2D, GL.textures[texture]); //此处为OpenGL使用方式
    console.log("------------------------",texture);
}