<template>
  <div class="move">
    <div class="leftControls">
      <h1 style="color: #0C5582;text-align: center;">海上智能船舶模拟器</h1>
    <div class="controls">
      <button @click="toggleConnection">{{ connectButtonText }}</button>
      <button :disabled="!isConnected || isSimulating" @click="startSimulation">开始仿真</button>
      <button class="stop" :disabled="!isSimulating" @click="stopSimulation">停止仿真</button>
    </div>
    <div class="status">状态: {{ statusText }}</div>

     <!-- 左侧面板 -->
     <div class="left-panel">
        <!-- <div class="data-box">
          <h3>能量节点</h3>
          <div v-for="(node, index) in cnNodes" :key="'node'+index" class="energy-node-item">
            节点{{ index+1 }}: ESS={{ node.ess }}kWh ({{ node.essPercent }}%)
          </div>
        </div> -->
        <div class="energy-info">
          <h3>能量节点实时数据</h3>
          <div v-for="(node, index) in cnNodes" :key="'info'+index">
            节点{{ index }}: ESS={{ node.ess }}kWh ({{ node.essPercent }}%), 
            风力={{ node.wind }}kW, 太阳能={{ node.solar }}kW
          </div>
        </div>
        
        <div class="data-box">
          <h3>智能体状态</h3>
          <div v-for="(ship, index) in ships" :key="'ship'+index" class="agent-item">
            船舶{{ index+1 }}: 速度={{ ship.speed }}km/h, 电量={{ ship.battery }}%
          </div>
        </div>
      </div>
    </div>

     <!-- 地图面板 -->
     <div class="map-panel">
        <h3 style="font-size: 0.9vw;font-weight: 600;">海域地图 (400,000m × 250,000m)</h3>
        <div class="canvas-move">
          <canvas ref="mapCanvas"></canvas>
          <div class="map-objects">
            <div v-for="(node, index) in cnNodes" 
                 :key="'cn'+index"
                 class="energy-node"
                 style="width: 3%;height: 3%;"
                 :style="nodeStyle(node)">
              {{ index }}
            </div>
            <div v-for="(ship, index) in ships"
                 :key="'agent'+index"
                 class="agent"
                 style="width: 3%;height: 3%;"
                 :style="agentStyle(ship)">
              {{ index }}
            </div>
          </div>
        </div>
      </div>

          <!-- 右侧面板 -->
          <div class="right-panel">
            <div class="krt" style="height: 70%;">
        <chart1></chart1>
        <chart2></chart2>
        <chart3></chart3>
    </div>
        <div class="console-info">
          <h3>控制台信息</h3>
          <div class="log" style="color: #000 !important;">
            <div v-for="(log, index) in logs" :key="'log'+index">[{{ log.time }}] {{ log.message }}</div>
          </div>
        </div>
      </div>
 
    

    <!-- 底部数据面板 -->
    <!-- <div class="data-move">
      <div class="data-box">
        <h3>船舶数据</h3>
        <div v-html="shipDataHtml"></div>
      </div>
      <div class="data-box">
        <h3>充电站数据</h3>
        <div v-html="cnDataHtml"></div>
      </div>
    </div> -->
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted, computed, nextTick } from 'vue'
import chart1 from "./components/chart1.vue"
import chart2 from "./components/chart2.vue"
import chart3 from "./components/chart3.vue"

// 响应式数据
const mapCanvas = ref(null)
const ctx = ref(null)
const socket = ref(null)
const isConnected = ref(false)
const isSimulating = ref(false)
const simulationTime = ref('')
const logs = ref([])
const cnNodes = reactive([])
const ships = reactive([])
const shipDataHtml = ref('尚无数据')
const cnDataHtml = ref('尚无数据')

// 常量
const mapWidth = 400000
const mapHeight = 250000
const obstacles = [] // 可根据需要添加障碍物数据

// 计算属性
const connectButtonText = computed(() => isConnected.value ? '断开连接' : '连接服务器')
const statusText = computed(() => {
  if (!isConnected.value) return '未连接'
  return isSimulating.value ? `运行中 - 模拟时间: ${simulationTime.value}` : '已连接'
})

// 方法
const addLog = (message) => {
  logs.value.push({
    time: new Date().toLocaleTimeString(),
    message
  })
  // 保持日志最多100条
  if (logs.value.length > 100) logs.value.shift()
}

const nodeStyle = (node) => ({
  left: `${(node.x / mapWidth) * 100}%`,
  top: `${(1 - node.y / mapHeight) * 100}%`,
  backgroundColor: `rgba(255, 82, 82, ${0.5 + (node.ess / 4000) * 0.5})`
})

const agentStyle = (ship) => ({
  left: `${(ship.x / mapWidth) * 100}%`,
  top: `${(1 - ship.y / mapHeight) * 100}%`,
  backgroundColor: `rgb(${255 * (1 - ship.battery / 100)}, ${255 * (ship.battery / 100)}, 0)`
})

// WebSocket 相关方法
const toggleConnection = () => {
  if (isConnected.value) {
    disconnect()
  } else {
    connect()
  }
}

const connect = () => {
  socket.value = new WebSocket('wss://pusv.sjtuee.net/ws')

  socket.value.onopen = () => {
    isConnected.value = true
    addLog('WebSocket连接已建立')
    initMap()
  }

  socket.value.onmessage = (event) => {
    const data = JSON.parse(event.data)
    
    if (data.status) {
      handleStatusMessage(data)
    } else if (data.posInfo && data.CNInfo) {
      handleSimulationData(data)
    }
  }

  socket.value.onclose = () => {
    isConnected.value = false
    isSimulating.value = false
    addLog('WebSocket连接已关闭')
  }

  socket.value.onerror = (error) => {
    addLog('WebSocket错误: ' + JSON.stringify(error))
  }
}

const disconnect = () => {
  if (socket.value) {
    socket.value.close()
    socket.value = null
  }
}

const handleStatusMessage = (data) => {
  addLog(`服务器消息: ${data.message}`)
  if (data.status === 'starting') {
    isSimulating.value = true
  } else if (data.status === 'stopped') {
    isSimulating.value = false
  }
}

const handleSimulationData = (data) => {
  simulationTime.value = data.time
  isSimulating.value = true

  // 更新充电站数据
  cnNodes.splice(0, cnNodes.length, ...data.CNInfo.map(cn => ({
    x: cn[0],
    y: cn[1],
    ess: cn[2].toFixed(0),
    essPercent: (cn[2] / 4000 * 100).toFixed(0),
    wind: cn[3].toFixed(0),
    solar: cn[4].toFixed(0)
  })))

  // 更新船舶数据
  ships.splice(0, ships.length, ...data.posInfo.map(ship => ({
    x: ship[0],
    y: ship[1],
    speed: ship[2].toFixed(1),
    battery: (ship[3] / 6643 * 100).toFixed(0)
  })))

  // 更新表格数据
  updateTables(data)
}

const updateTables = (data) => {
  shipDataHtml.value = generateTableHTML(data.posInfo, '船舶', ['X', 'Y', '速度', '电量 (%)'])
  cnDataHtml.value = generateTableHTML(data.CNInfo, '充电站', ['X', 'Y', '储能 (kWh)', '风力 (kW)', '太阳能 (kW)'])
}

const generateTableHTML = (data, title, headers) => {
  return `<table border="1" style="width:100%; border-collapse: collapse;">
    <tr><th>ID</th>${headers.map(h => `<th>${h}</th>`).join('')}</tr>
    ${data.map((item, index) => `
      <tr><td>${index}</td>
      ${item.map((val, i) => `<td>${i === 3 ? (val / 6643 * 100).toFixed(1) + '%' : val.toFixed(2)}</td>`).join('')}
      </tr>`
    ).join('')}
  </table>`
}

// 地图相关方法
const initMap = () => {
  nextTick(() => {
    const canvas = mapCanvas.value
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight
    ctx.value = canvas.getContext('2d')
    drawMap()
  })
}

const drawMap = () => {
  if (!ctx.value) return

  ctx.value.clearRect(0, 0, canvas.width, canvas.height)
  
  // 绘制网格
  ctx.value.strokeStyle = '#ddd'
  ctx.value.lineWidth = 0.5

  // 纵向网格线
  for (let x = 0; x <= mapWidth; x += 50000) {
    const canvasX = (x / mapWidth) * canvas.width
    ctx.value.beginPath()
    ctx.value.moveTo(canvasX, 0)
    ctx.value.lineTo(canvasX, canvas.height)
    ctx.value.stroke()
  }

  // 横向网格线
  for (let y = 0; y <= mapHeight; y += 50000) {
    const canvasY = (y / mapHeight) * canvas.height
    ctx.value.beginPath()
    ctx.value.moveTo(0, canvasY)
    ctx.value.lineTo(canvas.width, canvasY)
    ctx.value.stroke()
  }

  // 绘制障碍物（需要补充障碍物数据）
}

// 生命周期钩子
onMounted(() => {
  window.addEventListener('resize', initMap)
})

onUnmounted(() => {
  window.removeEventListener('resize', initMap)
  if (socket.value) socket.value.close()
})

// 仿真控制
const startSimulation = () => {
  socket.value.send('start')
  addLog('已发送启动命令')
}

const stopSimulation = () => {
  socket.value.send('stop')
  addLog('已发送停止命令')
}
</script>

<style>

        .move {
          width: 100%;
          height: 100%;
          background-color: #F0F8FF;
          display: flex;
          justify-content: space-between;
        }

        .leftControls{
          width: 20%;
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: space-around;
          padding: 0% 0.5%;
        }
.left-panel{
  height: 70%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
        .controls {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            font-size: 0.8vw;
        }

        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        button.stop {
            background-color: #f44336;
        }

        button.stop:hover {
            background-color: #d32f2f;
        }

        .status {
            padding: 10px;
            background-color: #E9E9E9;
            border-radius: 4px;
        }

        .main-content {
            display: flex;
            gap: 20px;
        }


        .map-panel {
            height: 100%;
            width: 60%;
            background-color: #B2CEFE;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            position: relative;
        }

        .right-panel {
            width: 20%;
            height: 100%;
        }

        .log {
            height: 85%;
            overflow-y: auto;
            padding: 10px;
            background-color: #fff;
            border-radius: 4px;
            font-family: monospace;
        }

        .data-move {
          width: 100%;
          height: 100%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .data-box {
            padding: 10px;
            background-color: #C00000;
            border-radius: 4px;
            color: #fff;
            height: 49%;
            overflow-y: auto;
        }

        .canvas-move {
            /* width: 100%;
            height: 100%; */
        }

        canvas {
            width: 100%;
            height: 100%;
            position: relative;
        }

        .energy-node {
            background-color: #FF5252;
            border-radius: 0;
            width: 25px;
            height: 25px;
            position: absolute;
            transform: translate(-50%, -50%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        .agent {
            background-color: #FFA500;
            border-radius: 50%;
            width: 15px;
            height: 15px;
            position: absolute;
            transform: translate(-50%, -50%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        .energy-info,
        .console-info {
            background-color: #ED7D31;
            color: white;
            padding: 10px;
            border-radius: 4px;
            height: 49%;
            overflow-y: auto;
        }

        .console-info {
            background-color: #8BC34A;
            height: 30%;
        }
    </style>