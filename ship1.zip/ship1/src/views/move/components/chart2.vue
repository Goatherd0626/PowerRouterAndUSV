<template>
  <div ref="chart2Container2" style="width: 100%; height: 33%;"></div>
</template>

<script>
import { onMounted, onUnmounted, ref } from 'vue';
import { Chart } from '@antv/g2';

export default {
  setup() {
    const chart2Container2 = ref(null);
    let chart2 = null;

    const data = [
      { year: '00:00', value: 4 },
      { year: '6:00', value: 2 },
      { year: '12:00', value: 4 },
      { year: '18:00', value: 1 },
      { year: '24:00', value: 3 },
    ];

    onMounted(() => {
      if (!chart2Container2.value) return;

      // 创建图表实例（v5 风格）
      chart2 = new Chart({
        container: chart2Container2.value,
        autoFit: true,
      });

      // 配置图表（使用 Options API）
      chart2.options({
        type: 'line', // 指定图表类型
        data: data,
        encode: {
          x: 'year',
          y: 'value',
        },
        scale: {
          x: { padding: 0.5 },
          y: { nice: true },
        },
        axis: {
          x: { title: '节点2实时出力曲线' },
          y: { title: '数值' },
        },
        tooltip: { 
          showMarkers: false, // 直接配置 tooltip
        },
        style: {
          shape: 'smooth', // 平滑曲线
          lineWidth: 2,
          stroke: '#1890ff',
        },
      });

      chart2.render();
    });

    onUnmounted(() => {
      chart2?.destroy();
    });

    return { chart2Container2 };
  }
};
</script>