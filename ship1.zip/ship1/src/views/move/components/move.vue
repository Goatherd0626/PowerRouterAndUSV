<template>
  <div class="scene">
    <img 
      :src="arrowImg"
      class="moving-object"
      :style="{
        transform: `translate(${position.x}px, ${position.y}px) rotate(${currentAngle}deg)`,
        transition: `transform ${useAnimation ? '0.3s linear' : '0s'}`
      }"
    >
    <button @click="startMotion">开始运动</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import arrowImg from '@/assets/ship.png' // 箭头图片需指向正右方

const position = ref({ x: 50, y: 50 })
const currentAngle = ref(0)
const useAnimation = ref(true)

// 运动路径示例
const path = [
{ x: 50, y: 50 },
  { x: 20, y: 20 },
  { x: 50, y: 30 },
  { x: 50, y: 10 }
]

const startMotion = async () => {
  for (const target of path) {
    await moveTo(target)
  }
}

const moveTo = (target) => {
  return new Promise(resolve => {
    const dx = target.x - position.value.x
    const dy = target.y - position.value.y
    
    // 计算运动方向角度（修正坐标系差异）
    currentAngle.value = Math.atan2(-dy, dx) * (180 / Math.PI)
    
    // 使用requestAnimationFrame实现平滑过渡
    const startTime = Date.now()
    const duration = 2000 // 1秒完成每个阶段
    
    const animate = () => {
      const progress = (Date.now() - startTime) / duration
      
      if (progress < 1) {
        position.value = {
          x: position.value.x + dx * progress,
          y: position.value.y + dy * progress
        }
        requestAnimationFrame(animate)
      } else {
        position.value = target
        resolve()
      }
    }
    
    requestAnimationFrame(animate)
  })
}
</script>

<style scoped>
.scene {
  position: relative;
  width: 600px;
  height: 400px;
  border: 1px solid #ccc;
}

.moving-object {
  position: absolute;
  width: 40px;
  height: 40px;
  transform-origin: center center; /* 确保绕中心旋转 */
  will-change: transform; /* 启用硬件加速 */
}

button {
  position: absolute;
  bottom: 10px;
  left: 10px;
}
</style>
