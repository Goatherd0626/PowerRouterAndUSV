<template>
  <div ref="chart3Container3" style="width: 100%; height: 33%;"></div>
</template>

<script>
import { onMounted, onUnmounted, ref } from 'vue';
import { Chart } from '@antv/g2';

export default {
  setup() {
    const chart3Container3 = ref(null);
    let chart3 = null;

    const data = [
      { year: '00:00', value: 1 },
      { year: '6:00', value: 4 },
      { year: '12:00', value: 1 },
      { year: '18:00', value: 3 },
      { year: '24:00', value:2 },
    ];

    onMounted(() => {
      if (!chart3Container3.value) return;

      // 创建图表实例（v5 风格）
      chart3 = new Chart({
        container: chart3Container3.value,
        autoFit: true,
      });

      // 配置图表（使用 Options API）
      chart3.options({
        type: 'line', // 指定图表类型
        data: data,
        encode: {
          x: 'year',
          y: 'value',
        },
        scale: {
          x: { padding: 0.5 },
          y: { nice: true },
        },
        axis: {
          x: { title: '节点3实时出力曲线' },
          y: { title: '数值' },
        },
        tooltip: { 
          showMarkers: false, // 直接配置 tooltip
        },
        style: {
          shape: 'smooth', // 平滑曲线
          lineWidth: 2,
          stroke: '#1890ff',
        },
      });

      chart3.render();
    });

    onUnmounted(() => {
      chart3?.destroy();
    });

    return { chart3Container3 };
  }
};
</script>