<template>
  <div ref="chartContainer" style="width: 100%; height: 33%;"></div>
</template>

<script>
import { onMounted, onUnmounted, ref } from 'vue';
import { Chart } from '@antv/g2';

export default {
  setup() {
    const chartContainer = ref(null);
    let chart = null;

    const data = [
      { year: '00:00', value: 3 },
      { year: '6:00', value: 4 },
      { year: '12:00', value: 3.5 },
      { year: '18:00', value: 5 },
      { year: '24:00', value: 3 },
    ];

    onMounted(() => {
      if (!chartContainer.value) return;

      // 创建图表实例（v5 风格）
      chart = new Chart({
        container: chartContainer.value,
        autoFit: true,
      });

      // 配置图表（使用 Options API）
      chart.options({
        type: 'line', // 指定图表类型
        data: data,
        encode: {
          x: 'year',
          y: 'value',
        },
        scale: {
          x: { padding: 0.5 },
          y: { nice: true },
        },
        axis: {
          x: { title: '节点1实时出力曲线' },
          y: { title: '数值' },
        },
        tooltip: { 
          showMarkers: false, // 直接配置 tooltip
        },
        style: {
          shape: 'smooth', // 平滑曲线
          lineWidth: 2,
          stroke: '#1890ff',
        },
      });

      chart.render();
    });

    onUnmounted(() => {
      chart?.destroy();
    });

    return { chartContainer };
  }
};
</script>